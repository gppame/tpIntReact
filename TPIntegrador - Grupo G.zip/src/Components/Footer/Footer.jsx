import React from 'react'
import './Footer.css'
const Footer = () => {
  return (
    <div className='Footer'>
      
      Derechos reservados &copy; 2023 - Grupo G
      
    </div>
  )
}

export default Footer
